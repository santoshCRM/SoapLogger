﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using XrmToolBox.Extensibility;
using System.ServiceModel.Description;
using System.Xml.Linq;
using System.Xml;

namespace Soaplogger
{
    public partial class Soaplogger : PluginControlBase
    {
        private List<EntityMetadata> entitymetadataCache;
        private List<GrdParameter> grdParameter;
        private List<Entity> actionCache;
        public Soaplogger()
        {
            InitializeComponent();
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
             base.CloseTool();//xrmtool
        }

        private void btn_rtvEnt_Click(object sender, EventArgs e)
        {
            this.drp_entitylist.Items.Clear();
             bool flag = base.Service != null;//xrmtool
            
            if (flag)
            {
                this.entitymetadataCache = new List<EntityMetadata>();
                RetrieveAllEntitiesResponse retrieveAllEntitiesResponse = (RetrieveAllEntitiesResponse)base.Service.Execute(new RetrieveAllEntitiesRequest());
                EntityMetadata[] entityMetadata = retrieveAllEntitiesResponse.EntityMetadata;
                for (int i = 0; i < entityMetadata.Length; i++)
                {
                    EntityMetadata item = entityMetadata[i];
                    this.entitymetadataCache.Add(item);
                }
                foreach (EntityMetadata current in this.entitymetadataCache)
                {
                    string text = (current.DisplayName != null && current.DisplayName.UserLocalizedLabel != null) ? current.DisplayName.UserLocalizedLabel.Label : "N/A";
                    bool flag2 = text != "N/A";
                    if (flag2)
                    {
                        ComboboxItem comboboxItem = new ComboboxItem();
                        comboboxItem.Text = text;
                        comboboxItem.Value = current.LogicalName;
                        comboboxItem.typeCode = current.ObjectTypeCode.Value;
                        this.drp_entitylist.Items.Add(comboboxItem);
                    }
                }
                //this.drp_entitylist.Sorted = true;
                ComboboxItem comboboxItem2 = new ComboboxItem();
                comboboxItem2.Text = "Global (none)";
                comboboxItem2.Value = "none";
                comboboxItem2.typeCode = 0;
                this.drp_entitylist.Items.Insert(0, comboboxItem2);
            }
        }

        private void btn_Run_Click(object sender, EventArgs e)
        {
            try
            {
                bool flag = this.drp_action.SelectedIndex > -1 && this.drp_entitylist.SelectedIndex > -1 && this.txt_recordid.Text != null;
                if (flag)
                {
                    SoapLoggerOrganizationService soapLoggerOrganizationService = new SoapLoggerOrganizationService(base.Service);//xrmtool
                    OrganizationRequest organizationRequest = new OrganizationRequest(((ComboboxItem)this.drp_action.SelectedItem).Value.ToString());
                    organizationRequest.Parameters.Add("Target", new EntityReference(((ComboboxItem)this.drp_entitylist.SelectedItem).Value.ToString(), new Guid(this.txt_recordid.Text)));
                    foreach (DataGridViewRow dataGridViewRow in ((IEnumerable)this.grd_parameter.Rows))
                    {
                        bool flag2 = dataGridViewRow.Cells[0].Value != null && dataGridViewRow.Cells[1].Value != null
                               && dataGridViewRow.Cells[3].Value != null;
                        if (flag2)
                        {
                            object value = dataGridViewRow.Cells[3].Value;
                            if (dataGridViewRow.Cells[1].Value.ToString() == "String")
                                value = Convert.ToString(value);
                            else if (dataGridViewRow.Cells[1].Value.ToString() == "Int32")
                                value = Convert.ToInt32(value);
                            else if (dataGridViewRow.Cells[1].Value.ToString() == "Boolean")
                                value = Convert.ToBoolean(value);
                            else if (dataGridViewRow.Cells[1].Value.ToString() == "DateTime")
                                value = Convert.ToDateTime(value);
                            else if (dataGridViewRow.Cells[1].Value.ToString() == "Decimal")
                                value = Convert.ToDecimal(value);
                            else if (dataGridViewRow.Cells[1].Value.ToString() == "Float")
                                value = Convert.ToDecimal(value);
                            else if (dataGridViewRow.Cells[1].Value.ToString() == "Money")
                                value = value as Money;
                            else if (dataGridViewRow.Cells[1].Value.ToString() == "Entity")
                            {
                                Entity ent = new Entity(value.ToString(), new Guid(dataGridViewRow.Cells[4].Value.ToString()));
                                value = ent;
                            }
                            else if (dataGridViewRow.Cells[1].Value.ToString() == "EntityReferance")
                            {
                                EntityReference entre = new EntityReference(value.ToString(), new Guid(dataGridViewRow.Cells[4].Value.ToString()));
                                value = entre;
                            }
                            organizationRequest.Parameters.Add((string)dataGridViewRow.Cells[0].Value, value);
                        }
                    }
                    soapLoggerOrganizationService.Execute(organizationRequest);
                    this.txt_output.Text = soapLoggerOrganizationService.SoapResult;
                }
                else
                {
                    MessageBox.Show("Either delete empty parameter or supply value.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void drp_entitylist_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool flag = this.drp_entitylist.SelectedIndex > -1;
            if (flag)
            {
                this.LoadActions();
            }
        }
        private void LoadActions()
        {
            this.drp_action.Items.Clear();
            bool flag = base.Service != null;//xrmtool
            if (flag)
            {
                this.actionCache = new List<Entity>();
                QueryExpression queryExpression = new QueryExpression();
                queryExpression.TopCount=new int?(2000);
                queryExpression.EntityName="workflow";
                queryExpression.ColumnSet=new ColumnSet();
                queryExpression.ColumnSet.Columns.Add("name");
                queryExpression.ColumnSet.Columns.Add("xaml");
                queryExpression.Criteria=new FilterExpression();
                queryExpression.Criteria.AddCondition("category", 0, new object[]
				{
					"3"
				});
                queryExpression.Criteria.AddCondition("type", 0, new object[]
				{
					"1"
				});
                queryExpression.Criteria.AddCondition("statuscode", 0, new object[]
				{
					"2"
				});
                queryExpression.Criteria.AddCondition("rendererobjecttypecode", ConditionOperator.Null);
                queryExpression.Criteria.AddCondition("primaryentity", 0, new object[]
				{
					((ComboboxItem)this.drp_entitylist.SelectedItem).typeCode
				});
                queryExpression.LinkEntities.Add(new LinkEntity("workflow", "sdkmessage", "sdkmessageid", "sdkmessageid", 0));
                queryExpression.LinkEntities[0].Columns.AddColumns(new string[]
				{
					"name"
				});
                queryExpression.LinkEntities[0].EntityAlias="Workflowinner";
                EntityCollection entityCollection = base.Service.RetrieveMultiple(queryExpression);//xrmtool
                foreach (Entity current in entityCollection.Entities)
                {
                    this.actionCache.Add(current);
                }
                foreach (Entity current2 in this.actionCache)
                {
                    bool flag2 = current2.Contains("Workflowinner.name") && current2.Attributes["Workflowinner.name"] != null;
                    if (flag2)
                    {
                        ComboboxItem comboboxItem = new ComboboxItem();
                        comboboxItem.Text = current2.Attributes["name"].ToString();
                        comboboxItem.Value = ((AliasedValue)current2.Attributes["Workflowinner.name"]).Value;
                        this.drp_action.Items.Add(comboboxItem);
                    }
                }
                this.drp_action.Sorted = true;
            }
        }

        private void drp_action_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool flag = this.drp_action.SelectedIndex > -1;
            if (flag)
            {
                if (((ComboboxItem)this.drp_entitylist.SelectedItem).typeCode != 0)
                {
                    txt_recordid.ReadOnly = false;
                    txt_recordid.Enabled = true;
                    GetrecordGuid();
                }
                else
                {
                    txt_recordid.Enabled = false;
                    txt_recordid.ReadOnly = true;
                }
                grdParameter = new List<GrdParameter>();
                for (int x = 0; x < actionCache.Count; x++)
                {
                    Entity Ent = actionCache[x];
                    if (Ent.Attributes["name"].ToString() == (((ComboboxItem)this.drp_action.SelectedItem).Text.ToString()))
                    {
                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(Ent.Attributes["xaml"].ToString());

                        XmlNodeList nodes = doc.GetElementsByTagName("x:Property");
                        XmlNodeList Inodes = doc.GetElementsByTagName("mxsw:ArgumentRequiredAttribute");

                        for (int y = 0; y < nodes.Count; y++)
                        {
                            XmlNode node = nodes[y];
                            if (!string.IsNullOrEmpty(node.InnerXml))
                            {
                                if (node.Attributes[0].Value.ToString() == "Target")
                                {

                                }
                                else
                                {

                                    string name = node.Attributes[0].Value.ToString();
                                    string type = node.Attributes[1].Value.ToString();
                                    if (type.Contains("InArgument"))
                                    {

                                        int intdex = type.IndexOf(':');
                                        int lastdex = type.IndexOf(')');
                                        type = type.Substring(intdex + 1, lastdex - intdex - 1); // EntityCollection    Picklist not supported
                                        if (type == "Boolean" || type == "DateTime" || type == "Decimal" || type == "Float" || type == "Int32" || type == "String"
                                            || type == "Money" || type == "Entity" || type == "EntityReference")
                                        {
                                            GrdParameter para = new GrdParameter();
                                            para.Name = name;
                                            para.Type = type;
                                            para.Required = Convert.ToBoolean(Inodes[y - 2].Attributes[0].Value);
                                            grdParameter.Add(para);

                                        }
                                        else
                                        {
                                            MessageBox.Show("This plugin does not support input argument type " + type);
                                        }

                                    }


                                }

                            }
                        }
                        break;
                    }
                }
                grd_parameter.DataSource = null;
                grd_parameter.DataSource = grdParameter;


                //foreach (DataGridViewRow dataGridViewRow in ((IEnumerable)this.grd_parameter.Rows))
                //{
                //    if (!dataGridViewRow.IsNewRow)
                //    grd_parameter.Rows.Remove(dataGridViewRow);


                //}


            }
        }
        private void GetrecordGuid()
        {
            try
            {

                string fetch = "<fetch top='50' >" +
"  <entity name='"+(((ComboboxItem)this.drp_entitylist.SelectedItem).Value.ToString())+"' >" +
"    <filter>" +
"      <condition attribute='statecode' operator='eq' value='0' />" +
"    </filter>" +
"  </entity>" +
"</fetch>";
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(fetch)
                };

                EntityCollection entityCollection = ((RetrieveMultipleResponse)base.Service.Execute(fetchRequest1)).EntityCollection;
                bool flag = entityCollection.Entities.Count > 0;
                if (flag)
                {
                    txt_recordid.Text = entityCollection.Entities[0].Id.ToString();
                }
                else
                {
                    MessageBox.Show("No Record Found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void Getparamenter()
        {
            try
            {
                QueryExpression queryExpression = new QueryExpression();
                queryExpression.TopCount=new int?(1);
                queryExpression.EntityName=(((ComboboxItem)this.drp_entitylist.SelectedItem).Value.ToString());
                EntityCollection entityCollection = base.Service.RetrieveMultiple(queryExpression);//xrmtool
                bool flag = entityCollection.Entities.Count > 0;
                if (flag)
                {
                    this.txt_recordid.Text = entityCollection.Entities[0].Id.ToString();
                }
                else
                {
                    MessageBox.Show("No Record Found");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void btn_convert_Click(object sender, EventArgs e)
        {
            this.txt_stringoutput.Text = SttingConverter.ConvertString(this.txt_output.Text);
        }

        private void btn_copy1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(this.txt_output.Text);
            MessageBox.Show("Output copied");
        }

        private void btn_copy2_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(this.txt_stringoutput.Text);
            MessageBox.Show("Text copied");
        }

        public static string GetConfigDataString(XmlDocument doc, string label)
        {
            return GetValueNode(doc, label);
        }
        private static string GetValueNode(XmlDocument doc, string key)
        {
            XmlNode node = doc.SelectSingleNode(String.Format("Settings/setting[@name='{0}']", key));
            if (node != null)
            {
                return node.SelectSingleNode("value").InnerText;
            }
            return string.Empty;
        }
    }
}
