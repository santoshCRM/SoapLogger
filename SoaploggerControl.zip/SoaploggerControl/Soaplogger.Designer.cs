﻿namespace Soaplogger
{
    partial class Soaplogger
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btn_Close = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_rtvEnt = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btn_Run = new System.Windows.Forms.ToolStripButton();
            this.drp_entitylist = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.drp_action = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_recordid = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_stringoutput = new System.Windows.Forms.TextBox();
            this.txt_output = new System.Windows.Forms.TextBox();
            this.btn_copy2 = new System.Windows.Forms.Button();
            this.btn_copy1 = new System.Windows.Forms.Button();
            this.btn_convert = new System.Windows.Forms.Button();
            this.grd_parameter = new System.Windows.Forms.DataGridView();
            this.Delete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd_parameter)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btn_Close,
            this.toolStripSeparator1,
            this.btn_rtvEnt,
            this.toolStripSeparator2,
            this.btn_Run});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1029, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btn_Close
            // 
            this.btn_Close.Image = global::Soaplogger.Properties.Resources.tsbClose_Image;
            this.btn_Close.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(56, 22);
            this.btn_Close.Text = "Close";
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btn_rtvEnt
            // 
            this.btn_rtvEnt.AccessibleName = "Retrieve Entities";
            this.btn_rtvEnt.Image = global::Soaplogger.Properties.Resources.tsbConnect_Image;
            this.btn_rtvEnt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_rtvEnt.Name = "btn_rtvEnt";
            this.btn_rtvEnt.Size = new System.Drawing.Size(110, 22);
            this.btn_rtvEnt.Text = "Retrieve Entities";
            this.btn_rtvEnt.ToolTipText = "Retrieve Entities";
            this.btn_rtvEnt.Click += new System.EventHandler(this.btn_rtvEnt_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // btn_Run
            // 
            this.btn_Run.Image = global::Soaplogger.Properties.Resources.tsbRun_Image;
            this.btn_Run.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btn_Run.Name = "btn_Run";
            this.btn_Run.Size = new System.Drawing.Size(48, 22);
            this.btn_Run.Text = "Run";
            this.btn_Run.Click += new System.EventHandler(this.btn_Run_Click);
            // 
            // drp_entitylist
            // 
            this.drp_entitylist.FormattingEnabled = true;
            this.drp_entitylist.Location = new System.Drawing.Point(15, 65);
            this.drp_entitylist.Name = "drp_entitylist";
            this.drp_entitylist.Size = new System.Drawing.Size(347, 21);
            this.drp_entitylist.TabIndex = 6;
            this.drp_entitylist.SelectedIndexChanged += new System.EventHandler(this.drp_entitylist_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Entity:";
            // 
            // drp_action
            // 
            this.drp_action.FormattingEnabled = true;
            this.drp_action.Location = new System.Drawing.Point(15, 116);
            this.drp_action.Name = "drp_action";
            this.drp_action.Size = new System.Drawing.Size(347, 21);
            this.drp_action.TabIndex = 8;
            this.drp_action.SelectedIndexChanged += new System.EventHandler(this.drp_action_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Action Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Record Guid:";
            // 
            // txt_recordid
            // 
            this.txt_recordid.Location = new System.Drawing.Point(15, 174);
            this.txt_recordid.Name = "txt_recordid";
            this.txt_recordid.Size = new System.Drawing.Size(347, 20);
            this.txt_recordid.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(382, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Add Parameter";
            // 
            // txt_stringoutput
            // 
            this.txt_stringoutput.Location = new System.Drawing.Point(568, 224);
            this.txt_stringoutput.Multiline = true;
            this.txt_stringoutput.Name = "txt_stringoutput";
            this.txt_stringoutput.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_stringoutput.Size = new System.Drawing.Size(456, 344);
            this.txt_stringoutput.TabIndex = 24;
            // 
            // txt_output
            // 
            this.txt_output.Location = new System.Drawing.Point(15, 224);
            this.txt_output.Multiline = true;
            this.txt_output.Name = "txt_output";
            this.txt_output.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txt_output.Size = new System.Drawing.Size(465, 344);
            this.txt_output.TabIndex = 23;
            // 
            // btn_copy2
            // 
            this.btn_copy2.Location = new System.Drawing.Point(729, 574);
            this.btn_copy2.Name = "btn_copy2";
            this.btn_copy2.Size = new System.Drawing.Size(112, 23);
            this.btn_copy2.TabIndex = 22;
            this.btn_copy2.Text = "Copy to clipboard";
            this.btn_copy2.UseVisualStyleBackColor = true;
            this.btn_copy2.Click += new System.EventHandler(this.btn_copy2_Click);
            // 
            // btn_copy1
            // 
            this.btn_copy1.Location = new System.Drawing.Point(119, 574);
            this.btn_copy1.Name = "btn_copy1";
            this.btn_copy1.Size = new System.Drawing.Size(111, 23);
            this.btn_copy1.TabIndex = 21;
            this.btn_copy1.Text = "Copy to clipboard";
            this.btn_copy1.UseVisualStyleBackColor = true;
            this.btn_copy1.Click += new System.EventHandler(this.btn_copy1_Click);
            // 
            // btn_convert
            // 
            this.btn_convert.Location = new System.Drawing.Point(500, 313);
            this.btn_convert.Name = "btn_convert";
            this.btn_convert.Size = new System.Drawing.Size(44, 24);
            this.btn_convert.TabIndex = 20;
            this.btn_convert.Text = ">>";
            this.btn_convert.UseVisualStyleBackColor = true;
            this.btn_convert.Click += new System.EventHandler(this.btn_convert_Click);
            // 
            // grd_parameter
            // 
            this.grd_parameter.AllowUserToAddRows = false;
            this.grd_parameter.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grd_parameter.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Delete,
            this.Column2,
            this.Column4,
            this.Column3,
            this.Column5,
            this.Column6});
            this.grd_parameter.Location = new System.Drawing.Point(383, 65);
            this.grd_parameter.Name = "grd_parameter";
            this.grd_parameter.Size = new System.Drawing.Size(641, 129);
            this.grd_parameter.TabIndex = 25;
            this.grd_parameter.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grd_parameter_CellContentDoubleClick);
            // 
            // Delete
            // 
            this.Delete.HeaderText = "Delete";
            this.Delete.Name = "Delete";
            this.Delete.Text = "Delete";
            this.Delete.ToolTipText = "Delete Row";
            this.Delete.Width = 70;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Name";
            this.Column2.HeaderText = "Name";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Type";
            this.Column4.HeaderText = "Type";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Required";
            this.Column3.HeaderText = "Required";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "ValueOrLogicalName";
            this.Column5.HeaderText = "ValueOrLogicalName";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "Guid";
            this.Column6.HeaderText = "Guid";
            this.Column6.Name = "Column6";
            // 
            // Soaplogger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1029, 561);
            this.Controls.Add(this.grd_parameter);
            this.Controls.Add(this.txt_stringoutput);
            this.Controls.Add(this.txt_output);
            this.Controls.Add(this.btn_copy2);
            this.Controls.Add(this.btn_copy1);
            this.Controls.Add(this.btn_convert);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_recordid);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.drp_action);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.drp_entitylist);
            this.Controls.Add(this.label1);
            this.Name = "Soaplogger";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grd_parameter)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton btn_Close;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btn_rtvEnt;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton btn_Run;
        private System.Windows.Forms.ComboBox drp_entitylist;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox drp_action;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_recordid;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_stringoutput;
        private System.Windows.Forms.TextBox txt_output;
        private System.Windows.Forms.Button btn_copy2;
        private System.Windows.Forms.Button btn_copy1;
        private System.Windows.Forms.Button btn_convert;
        private System.Windows.Forms.DataGridView grd_parameter;
        private System.Windows.Forms.DataGridViewButtonColumn Delete;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
    }
}
