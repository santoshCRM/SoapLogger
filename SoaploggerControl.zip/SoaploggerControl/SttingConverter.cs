using System;

namespace Soaplogger
{
	public static class SttingConverter
	{
		public static string ConvertString(string Input)
		{
			bool flag = string.IsNullOrWhiteSpace(Input);
			string result;
			if (flag)
			{
				result = string.Empty;
			}
			else
			{
				string text = string.Empty;
				string[] separator = new string[]
				{
					"\r\n"
				};
				string[] array = Input.Replace("\"", "'").Split(separator, StringSplitOptions.None);
				for (int i = 0; i < array.Length - 1; i++)
				{
					bool flag2 = array[i].Length <= 0;
					if (!flag2)
					{
						string text2 = array[i];
						bool flag3 = text2[0] == '-';
						if (flag3)
						{
							text2 = text2.ReplaceFirst("-", "");
						}
						else
						{
							for (int j = 1; j < text2.Length; j++)
							{
								bool flag4 = text2[j - 1] != ' ';
								if (flag4)
								{
									break;
								}
								bool flag5 = text2[j] == '-';
								if (flag5)
								{
									text2 = text2.ReplaceFirst("-", "");
									break;
								}
							}
						}
						string[] values = new string[]
						{
							text,
							"\"",
							text2,
							"\"+",
							Environment.NewLine
						};
						text = string.Concat(values);
					}
				}
				bool flag6 = array.Length != 0 && array[array.Length - 1].Length > 0;
				if (flag6)
				{
					text = text + "\"" + array[array.Length - 1] + "\";";
				}
				result = text;
			}
			return result;
		}

		public static string ReplaceFirst(this string text, string search, string replace)
		{
			int num = text.IndexOf(search);
			bool flag = num < 0;
			string result;
			if (flag)
			{
				result = text;
			}
			else
			{
				result = text.Substring(0, num) + replace + text.Substring(num + search.Length);
			}
			return result;
		}
	}
}
