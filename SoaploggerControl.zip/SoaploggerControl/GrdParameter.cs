﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Soaplogger
{
    internal class GrdParameter
    {
        string _Name;

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        string _Type;

        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        bool _Required;
        public bool Required
        {
            get { return _Required; }
            set { _Required = value; }
        }
        string _Value;
        public string ValueOrLogicalName
        {
            get { return _Value; }
            set { _Value = value; }
        }

        string _Guid;
        public string Guid
        {
            get { return _Guid; }
            set { _Guid = value; }
        }

    }
}
