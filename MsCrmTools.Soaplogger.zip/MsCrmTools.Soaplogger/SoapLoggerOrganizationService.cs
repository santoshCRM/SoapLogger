using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.CodeDom;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Xml;

namespace MsCrmTools.Soaplogger
{
	public class SoapLoggerOrganizationService
	{
		private sealed class StrongToLooseTypeSurrogate : IDataContractSurrogate
		{
			public object GetCustomDataToExport(Type clrType, Type dataContractType)
			{
				return null;
			}

			public object GetCustomDataToExport(MemberInfo memberInfo, Type dataContractType)
			{
				return null;
			}

			public Type GetDataContractType(Type type)
			{
				return type;
			}

			public object GetDeserializedObject(object obj, Type targetType)
			{
				return obj;
			}

			public void GetKnownCustomDataTypes(Collection<Type> customDataTypes)
			{
			}

			public object GetObjectToSerialize(object obj, Type targetType)
			{
				bool flag = obj != null && typeof(Entity).IsAssignableFrom(obj.GetType());
				object result;
				if (flag)
				{
					result = ((Entity)obj).ToEntity<Entity>();
				}
				else
				{
					result = obj;
				}
				return result;
			}

			public Type GetReferencedTypeOnImport(string typeName, string typeNamespace, object customData)
			{
				return null;
			}

			public CodeTypeDeclaration ProcessImportedType(CodeTypeDeclaration typeDeclaration, CodeCompileUnit compileUnit)
			{
				return typeDeclaration;
			}
		}

		[DataContract]
		private abstract class RequestBase
		{
			private const string SoapActionPrefix = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/";

			public string SoapAction
			{
				get;
				private set;
			}

			protected RequestBase()
			{
				DataContractAttribute[] array = (DataContractAttribute[])base.GetType().GetCustomAttributes(typeof(DataContractAttribute), true);
				bool flag = array == null || array.Length == 0;
				if (flag)
				{
					this.SoapAction = null;
				}
				else
				{
					this.SoapAction = "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/" + array[0].Name;
				}
			}

			public abstract SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service);
		}

		[DataContract]
		private abstract class ResponseBase
		{
		}

		[DataContract(Name = "Fault", Namespace = "http://www.w3.org/2003/05/soap-envelope")]
		private sealed class FaultResponse : SoapLoggerOrganizationService.ResponseBase
		{
			[DataMember(Name = "Code", Order = 1)]
			public SoapLoggerOrganizationService.FaultCode FaultCode
			{
				get;
				private set;
			}

			[DataMember(Name = "Reason", Order = 2)]
			public SoapLoggerOrganizationService.FaultReason FaultString
			{
				get;
				private set;
			}

			[DataMember(Name = "Detail", Order = 3)]
			public OrganizationServiceFault Detail
			{
				get;
				private set;
			}

			public FaultResponse()
			{
			}

			public FaultResponse(FaultException<OrganizationServiceFault> exception)
			{
				bool flag = exception == null;
				if (flag)
				{
					throw new ArgumentNullException("exception");
				}
				this.FaultCode = new SoapLoggerOrganizationService.FaultCode(exception.Code);
				this.FaultString = new SoapLoggerOrganizationService.FaultReason(exception.Message);
				this.Detail = exception.Detail;
			}
		}

		[DataContract(Namespace = "http://www.w3.org/2003/05/soap-envelope")]
		private sealed class FaultCode : SoapLoggerOrganizationService.ResponseBase
		{
			[DataMember(Name = "Value", Order = 1)]
			public string Value
			{
				get;
				private set;
			}

			public FaultCode()
			{
			}

			public FaultCode(System.ServiceModel.FaultCode code)
			{
				string str = null;
				bool flag = !string.IsNullOrWhiteSpace(code.Namespace);
				if (flag)
				{
					str = code.Namespace + ":";
				}
				this.Value = str + code.Name;
			}
		}

		[DataContract(Namespace = "http://www.w3.org/2003/05/soap-envelope")]
		private sealed class FaultReason : SoapLoggerOrganizationService.ResponseBase
		{
			[DataMember(Name = "Text", Order = 1)]
			public string Text
			{
				get;
				private set;
			}

			public FaultReason()
			{
			}

			public FaultReason(string text)
			{
				this.Text = text;
			}
		}

		[DataContract(Name = "Associate", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class AssociateRequest : SoapLoggerOrganizationService.RequestBase
		{
			[DataMember(Name = "entityName", Order = 1)]
			public string EntityName
			{
				get;
				private set;
			}

			[DataMember(Name = "entityId", Order = 2)]
			public Guid EntityId
			{
				get;
				private set;
			}

			[DataMember(Name = "relationship", Order = 3)]
			public Relationship Relationship
			{
				get;
				private set;
			}

			[DataMember(Name = "relatedEntities", Order = 4)]
			public EntityReferenceCollection RelatedEntities
			{
				get;
				private set;
			}

			public AssociateRequest(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
			{
				this.EntityName = entityName;
				this.EntityId = entityId;
				this.Relationship = relationship;
				this.RelatedEntities = relatedEntities;
			}

			public override SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service)
			{
				service.Associate(this.EntityName, this.EntityId, this.Relationship, this.RelatedEntities);
				return new SoapLoggerOrganizationService.AssociateResponse();
			}
		}

		[DataContract(Name = "AssociateResponse", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class AssociateResponse : SoapLoggerOrganizationService.ResponseBase
		{
		}

		[DataContract(Name = "Disassociate", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class DisassociateRequest : SoapLoggerOrganizationService.RequestBase
		{
			[DataMember(Name = "entityName", Order = 1)]
			public string EntityName
			{
				get;
				private set;
			}

			[DataMember(Name = "entityId", Order = 2)]
			public Guid EntityId
			{
				get;
				private set;
			}

			[DataMember(Name = "relationship", Order = 3)]
			public Relationship Relationship
			{
				get;
				private set;
			}

			[DataMember(Name = "relatedEntities", Order = 4)]
			public EntityReferenceCollection RelatedEntities
			{
				get;
				private set;
			}

			public DisassociateRequest(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
			{
				this.EntityName = entityName;
				this.EntityId = entityId;
				this.Relationship = relationship;
				this.RelatedEntities = relatedEntities;
			}

			public override SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service)
			{
				service.Disassociate(this.EntityName, this.EntityId, this.Relationship, this.RelatedEntities);
				return new SoapLoggerOrganizationService.DisassociateResponse();
			}
		}

		[DataContract(Name = "DisassociateResponse", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class DisassociateResponse : SoapLoggerOrganizationService.ResponseBase
		{
		}

		[DataContract(Name = "Create", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class CreateRequest : SoapLoggerOrganizationService.RequestBase
		{
			[DataMember(Name = "entity", Order = 1)]
			public Entity Entity
			{
				get;
				private set;
			}

			public CreateRequest(Entity entity)
			{
				this.Entity = entity;
			}

			public override SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service)
			{
				return new SoapLoggerOrganizationService.CreateResponse(service.Create(this.Entity));
			}
		}

		[DataContract(Name = "CreateResponse", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class CreateResponse : SoapLoggerOrganizationService.ResponseBase
		{
			[DataMember(Name = "CreateResult", Order = 1)]
			public Guid Id
			{
				get;
				private set;
			}

			public CreateResponse()
			{
			}

			public CreateResponse(Guid id)
			{
				this.Id = id;
			}
		}

		[DataContract(Name = "Delete", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class DeleteRequest : SoapLoggerOrganizationService.RequestBase
		{
			[DataMember(Name = "entityName", Order = 1)]
			public string EntityName
			{
				get;
				private set;
			}

			[DataMember(Name = "id", Order = 2)]
			public Guid EntityId
			{
				get;
				private set;
			}

			public DeleteRequest(string entityName, Guid id)
			{
				this.EntityName = entityName;
				this.EntityId = id;
			}

			public override SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service)
			{
				service.Delete(this.EntityName, this.EntityId);
				return new SoapLoggerOrganizationService.DeleteResponse();
			}
		}

		[DataContract(Name = "DeleteResponse", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class DeleteResponse : SoapLoggerOrganizationService.ResponseBase
		{
		}

		[DataContract(Name = "Execute", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class ExecuteRequest : SoapLoggerOrganizationService.RequestBase
		{
			[DataMember(Name = "request", Order = 1)]
			public OrganizationRequest Request
			{
				get;
				private set;
			}

			public ExecuteRequest(OrganizationRequest request)
			{
				this.Request = request;
			}

			public override SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service)
			{
				return new SoapLoggerOrganizationService.ExecuteResponse(service.Execute(this.Request));
			}
		}

		[DataContract(Name = "ExecuteResponse", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class ExecuteResponse : SoapLoggerOrganizationService.ResponseBase
		{
			[DataMember(Name = "ExecuteResult", Order = 1)]
			public OrganizationResponse Response
			{
				get;
				private set;
			}

			public ExecuteResponse()
			{
			}

			public ExecuteResponse(OrganizationResponse response)
			{
				this.Response = response;
			}
		}

		[DataContract(Name = "Retrieve", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class RetrieveRequest : SoapLoggerOrganizationService.RequestBase
		{
			[DataMember(Name = "entityName", Order = 1)]
			public string EntityName
			{
				get;
				private set;
			}

			[DataMember(Name = "id", Order = 2)]
			public Guid Id
			{
				get;
				private set;
			}

			[DataMember(Name = "columnSet", Order = 3)]
			public ColumnSet Columns
			{
				get;
				private set;
			}

			public RetrieveRequest(string entityName, Guid id, ColumnSet columnSet)
			{
				this.EntityName = entityName;
				this.Id = id;
				this.Columns = columnSet;
			}

			public override SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service)
			{
				return new SoapLoggerOrganizationService.RetrieveResponse(service.Retrieve(this.EntityName, this.Id, this.Columns));
			}
		}

		[DataContract(Name = "RetrieveResponse", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class RetrieveResponse : SoapLoggerOrganizationService.ResponseBase
		{
			[DataMember(Name = "RetrieveResult", Order = 1)]
			public Entity Entity
			{
				get;
				private set;
			}

			public RetrieveResponse()
			{
			}

			public RetrieveResponse(Entity entity)
			{
				this.Entity = entity;
			}
		}

		[DataContract(Name = "RetrieveMultiple", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class RetrieveMultipleRequest : SoapLoggerOrganizationService.RequestBase
		{
			[DataMember(Name = "query", Order = 1)]
			public QueryBase Query
			{
				get;
				private set;
			}

			public RetrieveMultipleRequest(QueryBase query)
			{
				this.Query = query;
			}

			public override SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service)
			{
				return new SoapLoggerOrganizationService.RetrieveMultipleResponse(service.RetrieveMultiple(this.Query));
			}
		}

		[DataContract(Name = "RetrieveMultipleResponse", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class RetrieveMultipleResponse : SoapLoggerOrganizationService.ResponseBase
		{
			[DataMember(Name = "RetrieveMultipleResult", Order = 1)]
			public EntityCollection EntityCollection
			{
				get;
				private set;
			}

			public RetrieveMultipleResponse()
			{
			}

			public RetrieveMultipleResponse(EntityCollection results)
			{
				this.EntityCollection = results;
			}
		}

		[DataContract(Name = "Update", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class UpdateRequest : SoapLoggerOrganizationService.RequestBase
		{
			[DataMember(Name = "entity", Order = 1)]
			public Entity Entity
			{
				get;
				private set;
			}

			public UpdateRequest(Entity entity)
			{
				this.Entity = entity;
			}

			public override SoapLoggerOrganizationService.ResponseBase Execute(IOrganizationService service)
			{
				service.Update(this.Entity);
				return new SoapLoggerOrganizationService.UpdateResponse();
			}
		}

		[DataContract(Name = "UpdateResponse", Namespace = "http://schemas.microsoft.com/xrm/2011/Contracts/Services")]
		private sealed class UpdateResponse : SoapLoggerOrganizationService.ResponseBase
		{
		}

		public IOrganizationService InnerService;

		public string SoapResult = string.Empty;

		public SoapLoggerOrganizationService(IOrganizationService service)
		{
			bool flag = service == null;
			if (flag)
			{
				throw new ArgumentNullException("service");
			}
			this.InnerService = service;
		}

		public void Associate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
		{
			this.ExecuteSoapRequest<SoapLoggerOrganizationService.AssociateRequest, SoapLoggerOrganizationService.AssociateResponse>(new SoapLoggerOrganizationService.AssociateRequest(entityName, entityId, relationship, relatedEntities));
		}

		public Guid Create(Entity entity)
		{
			return this.ExecuteSoapRequest<SoapLoggerOrganizationService.CreateRequest, SoapLoggerOrganizationService.CreateResponse>(new SoapLoggerOrganizationService.CreateRequest(entity)).Id;
		}

		public void Delete(string entityName, Guid id)
		{
			this.ExecuteSoapRequest<SoapLoggerOrganizationService.DeleteRequest, SoapLoggerOrganizationService.DeleteResponse>(new SoapLoggerOrganizationService.DeleteRequest(entityName, id));
		}

		public void Disassociate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
		{
			this.ExecuteSoapRequest<SoapLoggerOrganizationService.DisassociateRequest, SoapLoggerOrganizationService.DisassociateResponse>(new SoapLoggerOrganizationService.DisassociateRequest(entityName, entityId, relationship, relatedEntities));
		}

		public OrganizationResponse Execute(OrganizationRequest request)
		{
			return this.ExecuteSoapRequest<SoapLoggerOrganizationService.ExecuteRequest, SoapLoggerOrganizationService.ExecuteResponse>(new SoapLoggerOrganizationService.ExecuteRequest(request)).Response;
		}

		public Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
		{
			return this.ExecuteSoapRequest<SoapLoggerOrganizationService.RetrieveRequest, SoapLoggerOrganizationService.RetrieveResponse>(new SoapLoggerOrganizationService.RetrieveRequest(entityName, id, columnSet)).Entity;
		}

		public EntityCollection RetrieveMultiple(QueryBase query)
		{
			return this.ExecuteSoapRequest<SoapLoggerOrganizationService.RetrieveMultipleRequest, SoapLoggerOrganizationService.RetrieveMultipleResponse>(new SoapLoggerOrganizationService.RetrieveMultipleRequest(query)).EntityCollection;
		}

		public void Update(Entity entity)
		{
			this.ExecuteSoapRequest<SoapLoggerOrganizationService.UpdateRequest, SoapLoggerOrganizationService.UpdateResponse>(new SoapLoggerOrganizationService.UpdateRequest(entity));
		}

		private TResponse ExecuteSoapRequest<TRequest, TResponse>(TRequest request) where TRequest : SoapLoggerOrganizationService.RequestBase where TResponse : SoapLoggerOrganizationService.ResponseBase
		{
			this.OutputSoapRequest(request);
			TResponse tResponse;
			try
			{
				tResponse = (TResponse)((object)request.Execute(this.InnerService));
			}
			catch (FaultException<OrganizationServiceFault> exception)
			{
				this.OutputSoapResponse(new SoapLoggerOrganizationService.FaultResponse(exception));
				throw;
			}
			this.OutputSoapResponse(tResponse);
			return tResponse;
		}

		private void OutputSoapRequest(SoapLoggerOrganizationService.RequestBase request)
		{
			this.SoapResult += Environment.NewLine;
			this.SoapResult += "HTTP REQUEST";
			this.SoapResult += new string('-', 50);
			this.SoapResult += Environment.NewLine;
			this.SoapResult += string.Format("POST {0}/XRMServices/2011/Organization.svc/web'", "Xrm.Page.context.getClientUrl()+'");
			this.SoapResult += Environment.NewLine;
			this.SoapResult += "Content-Type: text/xml; charset=utf-8";
			this.SoapResult += Environment.NewLine;
			this.SoapResult += string.Format("SOAPAction: {0}", request.SoapAction);
			this.SoapResult += Environment.NewLine;
			this.OutputSoapEnvelope(request);
			this.SoapResult += Environment.NewLine;
			this.SoapResult += new string('-', 50);
		}

		private void OutputSoapResponse(object response)
		{
			this.SoapResult += Environment.NewLine;
			this.SoapResult += "HTTP RESPONSE";
			this.SoapResult += new string('-', 50);
			this.SoapResult += Environment.NewLine;
			this.OutputSoapEnvelope(response);
			this.SoapResult += Environment.NewLine;
			this.SoapResult += new string('-', 50);
		}

		private void OutputSoapEnvelope(object value)
		{
			this.SoapResult += this.FormatXml(string.Format(CultureInfo.InvariantCulture, "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\"><s:Body>{0}</s:Body></s:Envelope>", new object[]
			{
				this.Serialize(value)
			}));
		}

		private string FormatXml(string xml)
		{
			string result;
			using (StringReader stringReader = new StringReader(xml))
			{
				XmlReaderSettings xmlReaderSettings = new XmlReaderSettings();
				xmlReaderSettings.IgnoreWhitespace = true;
				xmlReaderSettings.ConformanceLevel = ConformanceLevel.Fragment;
				XmlDocument xmlDocument = new XmlDocument();
				using (XmlReader xmlReader = XmlReader.Create(stringReader, xmlReaderSettings))
				{
					xmlDocument.XmlResolver = null;
					xmlDocument.Load(xmlReader);
				}
				XmlWriterSettings xmlWriterSettings = new XmlWriterSettings();
				xmlWriterSettings.Indent = true;
				xmlWriterSettings.OmitXmlDeclaration = true;
				using (StringWriter stringWriter = new StringWriter(CultureInfo.InvariantCulture))
				{
					using (XmlWriter xmlWriter = XmlWriter.Create(stringWriter, xmlWriterSettings))
					{
						xmlDocument.Save(xmlWriter);
					}
					result = stringWriter.ToString();
				}
			}
			return result;
		}

		private string Serialize(object value)
		{
			bool flag = value == null;
			string result;
			if (flag)
			{
				result = null;
			}
			else
			{
				using (MemoryStream memoryStream = new MemoryStream())
				{
					DataContractSerializer dataContractSerializer = new DataContractSerializer(value.GetType(), null, 2147483647, true, false, new SoapLoggerOrganizationService.StrongToLooseTypeSurrogate(), new KnownTypesResolver());
					dataContractSerializer.WriteObject(memoryStream, value);
					memoryStream.Seek(0L, SeekOrigin.Begin);
					using (StreamReader streamReader = new StreamReader(memoryStream))
					{
						result = streamReader.ReadToEnd();
					}
				}
			}
			return result;
		}
	}
}
