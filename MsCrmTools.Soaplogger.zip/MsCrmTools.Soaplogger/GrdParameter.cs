﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MsCrmTools.Soaplogger
{
   internal class GrdParameter
    {
        string _Name;

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        string _Type;

        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        string _Value;

        public string Value
        {
            get { return _Value; }
            set { _Value = value; }
        }
    }
}
